
package psp_hlc_04_grupal.Exceptions;

public class CustomExceptions {
    
}
