

package psp_hlc_04_grupal.Exceptions;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import psp_hlc_04_grupal.Model.Clases.Asignatura;
import java.util.*;
import psp_hlc_04_grupal.Model.Clases.Alumno;

public class MostrarDatosListaResumen {
    /*TO DO: Crear un metodo que recoga todos los elementos de Asignaturas
      y que calcule la nota media de las asignaturas de un alumno
    */
    //Statements y ResultSets simples
    
    private  PreparedStatement ps;
    ResultSet rs;
    
    public Alumno obtenerAlumno(String user) throws SQLException {
        List<Asignatura> asignaturas = new ArrayList<>();
        String query = "SELECT * FROM Alumno WHERE usuario = ?";
        this.ps = CommonActions.createVistaResumen(query);
        ps.setString(1, user);
        this.rs = ps.executeQuery();

        Alumno alum = null;

        // Verifica que el ResultSet no esté vacío antes de acceder a los datos
        if (rs.next()) {
            // Obtiene la fecha de nacimiento como Date de la base de datos
            Date fechaNacSQL = rs.getDate("fechaNac");

            // Convierte la fecha a GregorianCalendar
            GregorianCalendar fechaNacGregorian = null;
            if (fechaNacSQL != null) {
                fechaNacGregorian = new GregorianCalendar();
                fechaNacGregorian.setTime(fechaNacSQL);
            }

            // Crea el objeto Alumno con la fecha de nacimiento en formato GregorianCalendar
            alum = new Alumno(
                rs.getInt("numAlum"),
                rs.getString("usuario"),
                rs.getString("contraseña"),
                fechaNacGregorian,
                rs.getInt("notaMedia"),
                rs.getString("img_route")
            );
        }

        // Cierra el ResultSet
        rs.close();
        return alum;
    }


    public List<Asignatura> obtenerAsignaturasPorAlumno(int codAlum) throws SQLException {
       // Consulta SQL para obtener las asignaturas de un alumno por su código
       String query = "SELECT * FROM Asignatura WHERE codAlum = ?";

       // Preparar la consulta usando PreparedStatement
       ps = CommonActions.getConn().prepareStatement(query);
       ps.setInt(1, codAlum); // Establecer el valor del parámetro en la consulta

       // Ejecutar la consulta y obtener el ResultSet
       ResultSet rs = ps.executeQuery();

       // Crear una lista para almacenar las asignaturas
       List<Asignatura> asignaturas = new ArrayList<>();

       // Iterar sobre el ResultSet y crear objetos Asignatura
       while (rs.next()) {
           Asignatura asignatura = new Asignatura(
               rs.getInt("codasig"),    // Código de la asignatura
               rs.getString("nomasig"), // Nombre de la asignatura
               rs.getFloat("nota"),     // Nota de la asignatura
               rs.getInt("codAlum")     // Código del alumno
           );
           asignaturas.add(asignatura); // Añadir la asignatura a la lista
       }

       // Cerrar ResultSet y PreparedStatement
       rs.close();

       // Devolver la lista de asignaturas
       return asignaturas;
   }

    
    public float calcularNotaMedia(int codAlum) throws SQLException {
        // Obtener la lista de asignaturas para el alumno
        List<Asignatura> listaA = obtenerAsignaturasPorAlumno(codAlum);

        // Verificar si la lista está vacía para evitar divisiones por cero
        if (listaA.isEmpty()) {
            return 0.0f; // Si no hay asignaturas, retornamos 0
        }

        // Variable para acumular la suma de las notas
        float sumaNotas = 0;

        // Iterar sobre cada asignatura en la lista
        for (Asignatura asignatura : listaA) {
            sumaNotas += asignatura.getNota(); // Sumar la nota de la asignatura
        }

        // Calcular la media (promedio)
        return sumaNotas / listaA.size(); // Dividir la suma total de notas entre el número de asignaturas
    }
    
    public int cambiarFechaAlumno(int codAlum, Date fechaNac) throws SQLException {
        // Consulta SQL para actualizar la fecha de nacimiento
        String query = "UPDATE Alumno SET fechaNac = ? WHERE numAlum = ?";

        // Preparar la sentencia
        ps = CommonActions.getConn().prepareStatement(query);
        System.out.println(fechaNac.getTime());
        // Establecer los parámetros de la consulta
        ps.setDate(1, new java.sql.Date(fechaNac.getTime()));  // Establecer la fecha de nacimiento convertida
        ps.setInt(2, codAlum);    // Establecer el código del alumno

        // Ejecutar la actualización
        int rowsAffected = ps.executeUpdate();

        // Cerrar la sentencia preparada
        ps.close();
        return rowsAffected;
    }

    public void cerrarRecursos() throws SQLException {
        if (ps != null && !ps.isClosed()) ps.close();
        CommonActions.cerrarConexion();
    }
}
