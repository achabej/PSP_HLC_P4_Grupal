
package psp_hlc_04_grupal.Exceptions;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import psp_hlc_04_grupal.Model.Clases.Asignatura;

public class DesplazamientoListaDetalle {
    //TO DO: Crear metodos para avanzar y retroceder en la lista detalle
    //Usar en statements TYPE_SCROLL_SENSITIVE e INSENSITIVE
    
    private PreparedStatement ps;
    private ResultSet rs;
    public ArrayList<Asignatura> listaAsig;
    
    public void cargarAsignaturas() throws SQLException {
        String user = CommonActions.getUser(); // Obtiene el usuario actual
        System.out.println("Usuario actual: " + user); // Verifica el usuario en la consola

        String query = "SELECT * FROM Asignatura WHERE codAlum IN (SELECT numAlum FROM Alumno WHERE usuario = ?)";
        this.ps = CommonActions.createVistaDetalle(query);
        ps.setString(1, user); // Establece el parámetro de usuario

        // Ejecuta la consulta
        this.rs = ps.executeQuery();

        if (!rs.isBeforeFirst()) { // Verifica si el ResultSet está vacío
            System.out.println("No se encontraron asignaturas para el usuario: " + user);
            throw new SQLException("No se encontraron asignaturas para el usuario: " + user);
        }
    }

    public boolean avanzar() throws SQLException {
        // Mueve el cursor al siguiente registro
        return rs.next();
    }

    public boolean retroceder() throws SQLException {
        // Mueve el cursor al registro anterior
        return rs.previous();
    }

    public boolean esPrimero() throws SQLException {
        // Verifica si el cursor está en el primer registro
        return rs.isFirst();
    }

    public boolean esUltimo() throws SQLException {
        // Verifica si el cursor está en el último registro
        return rs.isLast();
    }

    public boolean irPrimero() throws SQLException {
        // Mueve el cursor al primer registro
        return rs.first();
    }

    public boolean irUltimo() throws SQLException {
        // Mueve el cursor al último registro
         if (rs != null) {
            return rs.last();  // Mueve el cursor al último registro
        } else {
            throw new SQLException("El ResultSet no ha sido inicializado.");
        }
    }
    
    public int obtenerCodAlumnoPorUsuario(String usuario) throws SQLException {
        String query = "SELECT numAlum FROM Alumno WHERE usuario = ?";
        try (PreparedStatement ps = CommonActions.getConn().prepareStatement(query)) {
            ps.setString(1, usuario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("numAlum"); // Retorna el código del alumno logado
                } else {
                    throw new SQLException("No se encontró ningún alumno con el usuario: " + usuario);
                }
            }
        }
    }

    public void actualizarNotaActual(int codAsig, double nuevaNota) throws SQLException {
        // Obtener el usuario logado y luego su código de alumno
        String usuario = CommonActions.getUser();
        int codAlum = obtenerCodAlumnoPorUsuario(usuario); // Llamada interna

        String query = "UPDATE Asignatura SET nota = ? WHERE codAsig = ? AND codAlum = ?";

        try (PreparedStatement psUpdate = CommonActions.getConn().prepareStatement(query)) {
            psUpdate.setDouble(1, nuevaNota); // Nueva nota
            psUpdate.setInt(2, codAsig);      // Código de la asignatura
            psUpdate.setInt(3, codAlum);      // Código del alumno logado

            int rowsAffected = psUpdate.executeUpdate(); // Ejecuta la actualización
            CommonActions.getConn().commit(); // Confirma los cambios

            if (rowsAffected == 0) {
                throw new SQLException("No se encontró ninguna asignatura para actualizar con el código y usuario especificados.");
            }
        } catch (SQLException e) {
            CommonActions.getConn().rollback(); // Deshace los cambios en caso de error
            throw new SQLException("Error al actualizar la nota: " + e.getMessage(), e);
        }
    }


    public void cerrarRecursos() throws SQLException {
        // Cierra ResultSet y Statement para evitar fugas de memoria
        if (rs != null && !rs.isClosed()) rs.close();
        if (ps != null && !ps.isClosed()) ps.close();
        CommonActions.cerrarConexion();
    }
    
    public ResultSet getRS(){
        return rs;
    }
}


