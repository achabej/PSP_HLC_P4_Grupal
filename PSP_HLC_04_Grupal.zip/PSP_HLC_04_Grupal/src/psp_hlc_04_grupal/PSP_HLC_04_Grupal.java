package psp_hlc_04_grupal;

import javax.swing.JFrame;
import psp_hlc_04_grupal.View.menuPrincipal;

public class PSP_HLC_04_Grupal {

    public static void main(String[] args) {
        menuPrincipal frame = new menuPrincipal();
        
        // Configurar algunas propiedades de la ventana
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);  
    }
    
}
